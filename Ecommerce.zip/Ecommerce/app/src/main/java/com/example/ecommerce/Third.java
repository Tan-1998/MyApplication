package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Third extends AppCompatActivity {
    private Button bb1;
    private TextView tt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        Intent in=getIntent();
        String Final_selection =in.getStringExtra(Fourth.EXTRA_Final_selection);
        tt1=(TextView)findViewById(R.id.t1);
        tt1.setText(Final_selection );
        bb1=(Button)findViewById(R.id.b2);
        bb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Third.this,Fourth.class);
                startActivity(in);
            }
        });
    };
    }

