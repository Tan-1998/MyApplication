package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class Fourth extends AppCompatActivity {
    private TextView tt2;
    public static final String EXTRA_Final_selection="com.example.ecommerce.EXTRA_Final_selection";
    ArrayList<String> selection=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);
        tt2=(TextView)findViewById(R.id.t3);
        tt2.setEnabled(false);

    }
    public  void  SelectItem(View view){
        boolean checked=((CheckBox) view).isChecked();
        switch(view.getId())
        {
            case R.id.c1:
                if (checked)
                {
                    selection.add("Amazon");
                }
                else
                {
                    selection.remove("Amazon");
                }
                break;
            case R.id.c2:
                if (checked)
                {
                    selection.add("Snapdeal");
                }
                else
                {
                    selection.remove("Snapdeal");
                }
                break;
            case R.id.c3:
                if (checked)
                {
                    selection.add("Flipkart");
                }
                else
                {
                    selection.remove("Flipkart");
                }
                break;


        }

    }


    public void selections(View view) {
        String Final_selection=" ";
        for(String Sel :selection)
        {
            Final_selection=Final_selection+ Sel+"\n ";

        }
        tt2.setText( Final_selection);
        tt2.setEnabled(true);
    }
}
